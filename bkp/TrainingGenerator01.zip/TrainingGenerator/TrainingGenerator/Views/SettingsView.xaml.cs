﻿using System.Windows.Controls;

namespace TrainingGenerator.Views
{
    public partial class SettingsView : UserControl
    {
        public SettingsView()
        {
            InitializeComponent();
        }
    }
}