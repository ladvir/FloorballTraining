﻿using System.Windows.Controls;

namespace TrainingGenerator.Views
{
    public partial class DashboardView : UserControl
    {
        public DashboardView()
        {
            InitializeComponent();
        }
    }
}