﻿using System.Windows.Controls;

namespace TrainingGenerator.Views
{
    /// <summary>
    /// Interaction logic for AddActivityView.xaml
    /// </summary>
    public partial class AddActivityView : UserControl
    {
        public AddActivityView()
        {
            InitializeComponent();
        }
    }
}