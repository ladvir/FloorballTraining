﻿using System.Windows.Controls;

namespace TrainingGenerator.Views
{
    /// <summary>
    /// Interaction logic for ActivityDetailView.xaml
    /// </summary>
    public partial class ActivityDetailView : UserControl
    {
        public ActivityDetailView()
        {
            InitializeComponent();
        }
    }
}