﻿using NUnit.Framework;

namespace TrainingGenerator.Tests
{
    [TestFixture]
    public class ActivityTests
    {
        [Test]
        public void AddNewActivity()
        {
        }
    }
}